<div id="sidebar">
	<h2>Paesent scelerisque</h2>
	<ul>
		<li><a href="#">DIV with ID sidebar</a></li>
		<li><a href="#">Etiam rhoncus volutpat erat</a></li>
		<li><a href="#">Donec dictum metus in sapien</a></li>
	</ul>
</div>